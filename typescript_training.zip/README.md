# Initialize with

    npm install

# VS-Code Extensions

- Auto Import 
- Auto Rename Tag
- ESLint
- Live Server
- Material Icon Theme
