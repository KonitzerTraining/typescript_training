/**
 * @type {string}
 */
declare let s: string;
declare class ACMELib {
    /**
     * @returns {string}
     */
    getInfo(): string;
}
