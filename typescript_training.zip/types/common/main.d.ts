declare namespace ACME {
    export let info;
}