import { applyMixins, CardItem, Component } from "../../lib/core.js";
export class ProductComponent {
    init() {
        const data = this.getData();
        console.log(data);
        const html = this.render(data, this.template);
        console.log(html);
    }
    getData() {
        return {
            id: 3,
            title: "Haus"
        };
    }
}
applyMixins(ProductComponent, [Component, CardItem]);
//# sourceMappingURL=product.component.js.map