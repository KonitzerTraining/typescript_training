import { applyMixins, CardItem, Component, OnInit } from "../../lib/core.js";

export interface ProductComponent extends Component, CardItem {}
export class ProductComponent implements OnInit {

    init(): void {
        const data = this.getData();    
        console.log(data);
        const html = this.render(data, this.template);
        console.log(html);
    }

    getData() {
        return {
            id: 3,
            title: "Haus"
        };
    }
}

applyMixins(ProductComponent, [Component, CardItem]);

