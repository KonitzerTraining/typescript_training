import { ProductComponent } from "./product/product.component.js";
const p = new ProductComponent();
console.log(p);
p.init();
//# sourceMappingURL=main.js.map