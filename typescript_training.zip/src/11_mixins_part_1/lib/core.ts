export class Component {
    render (data: any, template: string) {

        for(const key in data) {
            template = template.replace("{{" + key + "}}", data[key]);
        }
        return template;
    }
}

export class CardItem {
    // Nicht möglich, da nicht im Prototype
    // template = "<h2>{{title}}</h2>"; 
    get template () {
        return "<h2>{{title}}</h2>";
    }
}

export function applyMixins(derivedCtor: any, constructors: any[]) {
    constructors.forEach((baseCtor) => {
        Object.getOwnPropertyNames(baseCtor.prototype).forEach((name) => {
            Object.defineProperty(
                derivedCtor.prototype,
                name,
                Object.getOwnPropertyDescriptor(baseCtor.prototype, name) ||
            Object.create(null)
            );
        });
    });
}

export interface OnInit {
      init() : void;
  }