function getData<T>(url: string): Promise<T> {
    return fetch(url).then((response) => {
        return response.json();
    })
}

interface User {
    id: number;
    email: string;
}
interface Product {
    id: number;
    artnr: string;
    title: string;
}
getData<User>('user.json').then((user) => {
    console.log(user);
})

getData<Product>('product.json').then((product: Product) => {
    console.log(product.title);
})