"use strict";
function getData(url) {
    return fetch(url).then((response) => {
        return response.json();
    });
}
getData('user.json').then((user) => {
    console.log(user);
});
getData('product.json').then((product) => {
    console.log(product.title);
});
//# sourceMappingURL=main.js.map