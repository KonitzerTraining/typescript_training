export default class Product {
    constructor({ id }) {
        // ES6 Reflect
        Reflect.defineProperty(this, "_id", {
            enumerable: true,
            value: id,
            writable: true
        });
    }
    // ES6
    get id() {
        return this._id;
    }
    // ES6
    set id(newId) {
        this._id = newId;
    }
    buy(product) {
        let out = null;
        if (typeof product === "string") {
            out = `${product} is now sold`;
        }
        else if (Array.isArray(product)) {
            out = product.map(name => `${name} is now sold`);
        }
        return out;
    }
}
const o = {
    a: 1, b: 2
};
const { a, b } = o;
console.log(a, b);
//# sourceMappingURL=product.component.js.map