export default class Product {
    // TS
    private _id!: number;

    constructor({id}: {id: number}) {
        // ES6 Reflect
        Reflect.defineProperty(this, "_id", {
            enumerable: true,
            value: id,
            writable: true
        });
    }

    // ES6
    get id (): number {
        return this._id;
    }
    
    // ES6
    set id (newId) {
        this._id = newId;
    }

    // Overload signatures
    buy(product: string): string;
    buy(product: string[]): string[];    
    buy(product: unknown): unknown {
        let out: string | string[] | null = null;
        if(typeof product === "string") {
            out =  `${product} is now sold`;
        } else if (Array.isArray(product)) {
            out = product.map(name => `${name} is now sold`);
        } 
        return out;
    }
}

const o = {
    a: 1, b: 2
};

const {a, b} = o;
console.log(a, b);