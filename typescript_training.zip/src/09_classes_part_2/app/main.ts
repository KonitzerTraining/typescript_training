import Product from "./product/product.component.js";

const p = new Product({
    id: Math.ceil(Math.random() * 1e8)
});

console.log(p);
// console.log(p._id);
console.log(p.id);

p.id = Math.ceil(Math.random() * 1e8);
console.log(p.id);

const keys = Reflect.ownKeys(p);
for(const key of keys) {
    console.log(key, p[key]);
}

for(const key in p) {
    console.log(key);
}

/* const prop = Symbol("get");
const o = {
    [prop] () {
        
    }
}; */