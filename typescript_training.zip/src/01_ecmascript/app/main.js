console.log('ok');

// ES Datentypen
// number
console.log(typeof 34);
console.log(typeof NaN);

// string
console.log(typeof 'Text');
console.log(`Text
auf 
mehreren Zeilen
`);

// boolean
console.log(typeof 1 === '1'); 

// undefined
let x; // default ist undefined
console.log(typeof x);

// Symbol
let s1 = Symbol(); //unique value
let list = [];
console.log(list[Symbol.iterator]); // for..of

// function
function f1 () {}
console.log(typeof f1);

class A {}
console.log(typeof A);

// object
const o = new Object();
const o1 = {}; // object literal notation
console.log(typeof o);
console.log(typeof o1);
console.log(typeof null);

/* console.log(variable1);

if(!variable1) {
    console.log('OK');
}

var variable1 = null;
 */