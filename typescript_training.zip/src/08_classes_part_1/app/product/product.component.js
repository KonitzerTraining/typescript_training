export class Product {
    // Constructor
    // Properties in der Signatur erstellen lassen mit private/public
    constructor(config) {
        this.config = config;
        this.baseColor = "red"; // Implizit string
        this.crDate = new Date().toLocaleTimeString("de");
        this.reservations = 0;
        // Neue Syntax für private propertis in ES2022 
        // tsconfig.json:     "target": "esnext",     
        this.#privateProp = "Test";
        this.rank = 1;
        // this.id = this.createId();
        console.log(this.#privateProp);
        // ES6 Reflect API
        Reflect.defineProperty(this, "id", {
            value: this.createId(),
            enumerable: true,
            writable: false, configurable: false // default-Wert
        });
        if (this.config) {
            console.log(this.config.theme);
        }
    }
    // Neue Syntax für private propertis in ES2022 
    // tsconfig.json:     "target": "esnext",     
    #privateProp;
    // Public Methods implizit möglich
    makeReservation(r = 1) {
        this.reservations += r;
        return this.reservations;
    }
    // Privat Methods
    createId() {
        return Math.ceil(Math.random() * 1e8);
    }
    // Static Methods ES6
    static isProduct(p) {
        return p.constructor === Product;
    }
}
// Static Properties
// TS readonly
Product.version = "0.2.1";
//# sourceMappingURL=product.component.js.map