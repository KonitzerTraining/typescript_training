export class Product {
    
    // Public Properties
    rank: number; // implizit public
    public baseColor = "red"; // Implizit string
    public readonly crDate: string = new Date().toLocaleTimeString("de");
    public readonly id!: number; // Wird noch definiert

    public reservations = 0;

    // Private Properties
    private info!: string; // info wird befüllt werden
    private meta?: string; // darf undefined sein

    // Neue Syntax für private propertis in ES2022 
    // tsconfig.json:     "target": "esnext",     
    #privateProp = "Test";

    // Static Properties
    // TS readonly
    static readonly version = "0.2.1";

    // Constructor
    // Properties in der Signatur erstellen lassen mit private/public
    constructor(private config? : {theme: string}) {
        this.rank = 1;
        // this.id = this.createId();
        console.log(this.#privateProp);
        // ES6 Reflect API
        Reflect.defineProperty(this, "id", {
            value :this.createId(),
            enumerable: true,
            writable: false, configurable: false // default-Wert
        });

        if(this.config) {
            console.log(this.config.theme);
        }
    }

    // Public Methods implizit möglich
    public makeReservation(r = 1): number {
        this.reservations += r;
        return this.reservations;
    }

    // Privat Methods
    private createId (): number {
        return  Math.ceil(Math.random() * 1e8);
    }

    // Static Methods ES6
    static isProduct(p: any): boolean {
        return p.constructor === Product;
    }


}