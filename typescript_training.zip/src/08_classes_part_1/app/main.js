import { Product } from "./product/product.component.js";
const p = new Product({
    theme: "cyan"
});
console.log(p);
let res;
res = Product.isProduct(p);
console.log(res);
// Cannot assign to 'version' because it is a read-only property.
// Product.version = "asdf";
console.log(Product.version);
console.log(p.rank);
p.makeReservation(2);
res = p.makeReservation();
console.log(res);
// Property 'createId' is private and only accessible within class 'Product'.
// res = p.createId();
console.log(res);
// console.log(p.#privateProp);
console.log(p.id);
// Cannot assign to read only property 'id' of object '#<Product>'
// p.id = 2342345; 
console.log(p.id);
//# sourceMappingURL=main.js.map