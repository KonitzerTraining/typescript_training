"use strict";
console.group('TypeScript');
/*
ES-Datentypen
string, number, boolean, undefined, Symbol
function object
*/
// array literal notation
const list = [3, 4, 5]; // Listen sind object vom Typ
console.log(typeof list);
console.log(list.constructor.name);
let a; // undefined, nicht number zur Laufzeit
// Kompilierprozess bleibt hängen wenn "noEmitOnError": true,  
console.log(a, typeof a);
a = 23;
console.log(a);
/*
 Implizit durch Wertzuweisung
*/
// object literal notation = new Object();
const o = {
    color: 'blue',
    amount: 23
};
// Property 'corners' does not exist on type '{ color: string; amount: number; }'.
o.corners = 3;
console.log(o);
/*
    Explizit mit :Type
*/
const value01 = 'test';
// oder
const value02 = null;
console.log(value02, typeof value02);
// mit Wert
let role;
role = 'guest';
console.log(role);
// Listen
const items01 = ['test', 234];
console.log(items01);
const items02 = ['test', 234];
console.log(items02);
// Generic
const items03 = ['asdf'];
console.log(items03);
const items04 = ['asdf', null];
console.log(items04);
// Unbekannt
const z = 234; // simuliert vom Backend
const listOfSgrings = [];
// Typ von Hand festlegen
// addToList(z as unknown as string);
//addToList(z);
addToList('testString');
console.log(listOfSgrings);
function addToList(newItem) {
    // Laufzeitüberprüfung mus trotzdem durchgeführt werden!
    if (typeof newItem !== 'string')
        throw new TypeError('only strings allowed');
    listOfSgrings.push(newItem);
}
const established = 2003;
const homeTown = {
    city: "Berlin"
};
console.log(homeTown);
// ENUM
var Sendung;
(function (Sendung) {
    Sendung[Sendung["Versendet"] = 0] = "Versendet";
    Sendung[Sendung["Verloren"] = 1] = "Verloren";
    Sendung[Sendung["Gelagert"] = 2] = "Gelagert";
})(Sendung || (Sendung = {}));
/*
{
    0: "Versendet"
    1: "Verloren"
    2: "Gelagert"
    Gelagert: 2
    Verloren: 1
    Versendet: 0
}
*/
const myPost = Sendung.Gelagert;
console.log(Sendung);
console.log(Sendung.Gelagert);
console.log(Sendung[2]);
if (myPost === Sendung.Gelagert) {
    console.log('Hole Päckchen');
}
//# sourceMappingURL=main.js.map