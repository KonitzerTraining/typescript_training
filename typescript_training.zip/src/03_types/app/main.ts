console.group('TypeScript');

/*
ES-Datentypen
string, number, boolean, undefined, Symbol
function object
*/

// array literal notation
const list = [3,4,5]; // Listen sind object vom Typ
console.log(typeof list); 
console.log(list.constructor.name);

let a: number; // undefined, nicht number zur Laufzeit
// Kompilierprozess bleibt hängen wenn "noEmitOnError": true,  
console.log(a, typeof a);
a = 23;
console.log(a);

/* 
 Implizit durch Wertzuweisung
*/

// object literal notation = new Object();
const o = {
    color: 'blue',
    amount: 23
};

// Property 'corners' does not exist on type '{ color: string; amount: number; }'.
o.corners = 3;
console.log(o);

/* 
    Explizit mit :Type
*/
const value01: string = 'test';

// oder
const value02: string | null = null;
console.log(value02, typeof value02);

// mit Wert
let role: 'admin' | 'guest' | null;
role = 'guest';
console.log(role);

// Listen
const items01: string[] = ['test', 234];
console.log(items01);

type arrayValues = 'admin' | 'test'  
const items02: ( arrayValues | number)[] = ['test', 234];
console.log(items02);

// Generic
const items03: Array<string> = ['asdf'];
console.log(items03);

const items04: Array<string | number | null> = ['asdf', null];
console.log(items04);

// Unbekannt
const z = 234; // simuliert vom Backend
const listOfSgrings: string[] = [];

// Typ von Hand festlegen
// addToList(z as unknown as string);
//addToList(z);
addToList('testString');
console.log(listOfSgrings);

function addToList(newItem: string) {
    // Laufzeitüberprüfung mus trotzdem durchgeführt werden!
    if(typeof newItem !== 'string') throw new TypeError('only strings allowed');
    listOfSgrings.push(newItem);
}

// Eigener Datentyp
type year = number
const established: year = 2003;
type addr = {
    city: string | null
}

const homeTown: addr = {
    city: "Berlin"
}

console.log(homeTown);

// ENUM
enum Sendung {
    Versendet, Verloren, Gelagert
}

/*
{
    0: "Versendet"
    1: "Verloren"
    2: "Gelagert"
    Gelagert: 2
    Verloren: 1
    Versendet: 0
}
*/
const myPost: Sendung = Sendung.Gelagert;
console.log(Sendung);
console.log(Sendung.Gelagert);
console.log(Sendung[2]);

if(myPost === Sendung.Gelagert) {
    console.log('Hole Päckchen');
}