import { Component, Lock, Positive } from "../../lib/core.js";

/*
Support für Decorators
tsconfig
    "experimentalDecorators": true,              
    "emitDecoratorMetadata": true,      
    
    für esnext im target
        "useDefineForClassFields": false,     
*/
@Component({
    element: "product-show"
}) 
export class ProductComponent extends HTMLElement {
    description = "Shirt";

    @Positive
        price = -234;
    errors?: string;

    constructor() {
        super();
        this.createHtml();
    }

    @Lock
    createHtml () {
        this.innerHTML = `
            <h2>${this.description}</h2>
            <p>${this.price}</p>
            <p>${(this.errors)? this.errors: ""}</p>
        `;
    }
}

/* ProductComponent.prototype.createHtml = function () {
    console.log("ok");
}; */
// Component(ProductComponent);