var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Lock, Positive } from "../../lib/core.js";
/*
Support für Decorators
tsconfig
    "experimentalDecorators": true,
    "emitDecoratorMetadata": true,
    
    für esnext im target
        "useDefineForClassFields": false,
*/
let ProductComponent = class ProductComponent extends HTMLElement {
    constructor() {
        super();
        this.description = "Shirt";
        this.price = -234;
        this.createHtml();
    }
    createHtml() {
        this.innerHTML = `
            <h2>${this.description}</h2>
            <p>${this.price}</p>
            <p>${(this.errors) ? this.errors : ""}</p>
        `;
    }
};
__decorate([
    Positive,
    __metadata("design:type", Object)
], ProductComponent.prototype, "price", void 0);
__decorate([
    Lock,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ProductComponent.prototype, "createHtml", null);
ProductComponent = __decorate([
    Component({
        element: "product-show"
    }),
    __metadata("design:paramtypes", [])
], ProductComponent);
export { ProductComponent };
/* ProductComponent.prototype.createHtml = function () {
    console.log("ok");
}; */
// Component(ProductComponent);
//# sourceMappingURL=product.component.js.map