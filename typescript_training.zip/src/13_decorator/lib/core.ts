/* export function Component(constructor: CustomElementConstructor) {
    // Custome Element - WebsComponent
    customElements.define("product-show", constructor);
} */


// Decorator Factory
export function Component({element}: {element: string}) {
    return function (constructor: CustomElementConstructor) { 
    // Custome Element - WebsComponent
        customElements.define(element, constructor);
    };
}

// Method Decorator
export function Lock (
    target: any, 
    propertyName: string, 
    propertyDescriptor: PropertyDescriptor
) {
    console.log(target);
    console.log(propertyName);

    propertyDescriptor.writable = false;
}

// Property Decorator
export function Positive(target: any, propertyName: string) {
    console.log(propertyName);
    Reflect.defineProperty(target, propertyName, {
        set: function (newValue) {
            console.log(newValue);
            if (newValue < 0) {
                Reflect.defineProperty(target, "errors", {
                    value: "Only positive numbers allowed."
                });
                this.value = NaN;
            } else {
                this.value = newValue;
            }
        },
        get: function () {
            return this.value;
        }
    }
    );
}
