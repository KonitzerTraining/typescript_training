window.ACME = window.ACME || {};

(function (ACME) {
    ACME.info = "1.0.0";

}(window.ACME));