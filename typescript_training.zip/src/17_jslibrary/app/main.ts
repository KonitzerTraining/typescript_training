/*
d.ts Datei befindet sich unter types/common/main.d.ts

tsconfig.json
        "typeRoots": [
            "./types"
        ],     
index.html
        <script src="externallib.js"></script>
*/

console.log(ACME.info);
