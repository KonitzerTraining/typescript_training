"use strict";
console.log('ts');
//# sourceMappingURL=main.js.map