// interfaces
interface Address {
    zip: string;
    city: string;
    phone?: string;
}

const myAddress: Address = {
    zip: "52321",
    city: "Berlin"
};

console.log(myAddress.constructor.name);

interface Person extends Address {
    name: string;
}

const p1: Person = {
    name: "Hans",
    ...myAddress// ES6 Spread-Operator
}
console.log(p1);

class Employee implements Person {
    name: string = '';
    zip!: string; // wid noch befüllt, versprochen
    city: string = '';
    phone?: string | undefined;
    company: string = '[Default Company]';
}
const e1: Employee = {
    ...p1,
    company: 'ACME'
};

console.log(e1, typeof e1, e1.constructor.name)

const e2: Employee = new Employee();

console.log(e2, typeof e2, e2.constructor.name)
