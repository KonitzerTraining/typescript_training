"use strict";
const myAddress = {
    zip: "52321",
    city: "Berlin"
};
console.log(myAddress.constructor.name);
const p1 = {
    name: "Hans",
    ...myAddress // ES6 Spread-Operator
};
console.log(p1);
class Employee {
    constructor() {
        this.name = '';
        this.city = '';
        this.company = '[Default Company]';
    }
}
const e1 = {
    ...p1,
    company: 'ACME'
};
console.log(e1, typeof e1, e1.constructor.name);
const e2 = new Employee();
console.log(e2, typeof e2, e2.constructor.name);
//# sourceMappingURL=main.js.map