export class Component {
    render (data: any, template: string) {

        for(const key in data) {
            template = template.replace("{{" + key + "}}", data[key]);
        }
        return template;
    }
}