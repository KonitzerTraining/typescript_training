import { Component } from "../../lib/core.js";
export class ProductComponent extends Component {
    init() {
        this.getData();
    }
    getData() {
        this.data = {
            id: 3,
            title: "Haus"
        };
    }
}
function componentAsCardFactory(Base) {
    return class ComponentAsCard extends Base {
        get template() {
            return `
            <h2>{{title}}</h2>
            <p><em>{{id}}</em></p>
        `;
        }
    };
}
export const ProductAsCard = componentAsCardFactory(ProductComponent);
//# sourceMappingURL=product.component.js.map