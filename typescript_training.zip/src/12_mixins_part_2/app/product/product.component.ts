import { Component } from "../../lib/core.js";

export class ProductComponent extends Component {
    data!: { id: number; title: string; };

    init(): void {
        this.getData();    
    }

    getData() {
        this.data = {
            id: 3,
            title: "Haus"
        };
    }
}


type Constructor = new (...args: any []) => any;
function componentAsCardFactory<TBase extends Constructor>(Base: TBase) {
    return class ComponentAsCard extends Base {
        get template () { 
            return `
            <h2>{{title}}</h2>
            <p><em>{{id}}</em></p>
        `;
        }
    };
}


export const ProductAsCard = componentAsCardFactory(ProductComponent);

