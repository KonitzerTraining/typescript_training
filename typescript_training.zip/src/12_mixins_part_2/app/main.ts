import { ProductAsCard } from "./product/product.component.js";


const card = new ProductAsCard();
card.init();

const html = card.render(card.data, card.template);

const body = window.document.querySelector("body")!;
body.innerHTML += html;

let bodyHtml: string = window.document.querySelector("body")?.innerHTML as string;
bodyHtml += html;


