import { Product } from "./product/product.component.js";

const p = new Product;
console.log(p);
p.init();