import { Component, OnInit } from "../../lib/core.js";

export class Product extends Component implements OnInit {
    // data: { id: number; title: string; };
    data: any;

    constructor() {
        super();
        console.log(Component.version);
    }

    init(): void {
        console.log("init");
        const data = this.getData();
        this.render(data.title);
    }

    private getData() {
        return this.data = {
            id: 3,
            title: "Haus"
        };
    }
}