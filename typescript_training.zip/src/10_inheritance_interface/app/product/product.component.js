import { Component } from "../../lib/core.js";
export class Product extends Component {
    constructor() {
        super();
        console.log(Component.version);
    }
    init() {
        console.log("init");
        const data = this.getData();
        this.render(data.title);
    }
    getData() {
        return this.data = {
            id: 3,
            title: "Haus"
        };
    }
}
//# sourceMappingURL=product.component.js.map