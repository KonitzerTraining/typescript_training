export abstract class Component {
    static version = "1.32.34";
    render(data: string) {
        console.log(`Render ${data} as HTML.`);
    }
}


// nicht möglich, weil abstract
// const c = new Component();

export interface OnInit {
    init(): void;
}