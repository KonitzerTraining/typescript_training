export {};
//# sourceMappingURL=Product.js.map