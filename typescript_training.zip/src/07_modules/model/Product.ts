export default interface Product {
    id: number;
    artnr: string;
    title: string;
}