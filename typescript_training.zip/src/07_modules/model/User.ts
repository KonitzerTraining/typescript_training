export default interface User {
    id: number;
    email: string;
}