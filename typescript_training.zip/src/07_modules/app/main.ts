// Die beiden ersten Imports erhalten nur Interfaces
// type von Hand ergänzen
// Settings in der code-workspace Datei:
//	"javascript.preferences.importModuleSpecifierEnding": "js",
//  "typescript.preferences.importModuleSpecifierEnding": "js",

import type User from "../model/User.js";
import type Product from "../model/Product.js";
import version, { getData } from "../lib/core.js";
import * as core from "../lib/core.js";


console.log(core)
console.log(version);
// require('../lib/core.js', (core) => {})
 
core.getData<User>("user.json").then((user) => {
    console.log(user);
});

getData<Product>("product.json").then((product: Product) => {
    console.log(product.title);
});