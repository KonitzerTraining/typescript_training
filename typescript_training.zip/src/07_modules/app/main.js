// Die beiden ersten Imports erhalten nur Interfaces
// type von Hand ergänzen
// Settings in der code-workspace Datei:
//	"javascript.preferences.importModuleSpecifierEnding": "js",
//  "typescript.preferences.importModuleSpecifierEnding": "js",
import version, { getData } from "../lib/core.js";
import * as core from "../lib/core.js";
console.log(core);
console.log(version);
// require('../lib/core.js', (core) => {})
core.getData("user.json").then((user) => {
    console.log(user);
});
getData("product.json").then((product) => {
    console.log(product.title);
});
//# sourceMappingURL=main.js.map