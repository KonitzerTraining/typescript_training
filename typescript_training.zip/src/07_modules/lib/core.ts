export function getData<T>(url: string): Promise<T> {
    return fetch(url).then((response) => {
        return response.json();
    })
}

const version = '1.0.0';
export default version;