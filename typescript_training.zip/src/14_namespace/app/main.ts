import { Core } from "../lib/core.js";

console.log(Core.version);
console.log(Core.Helper.getLicence());

const text: Core.Types.info = "asdf";
console.log(text);
