import { Core } from "../lib/core.js";
console.log(Core.version);
console.log(Core.Helper.getLicence());
const text = "asdf";
console.log(text);
//# sourceMappingURL=main.js.map