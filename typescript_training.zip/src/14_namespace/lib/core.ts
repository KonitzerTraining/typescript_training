/* window.ACME = window.ACME || {};
window.ACME = (function () {
    return {};
}()); */

export namespace Core {
    const licence: Types.info = "MIT";
    export const version = "1.0.2-alpha";
    export namespace Types {
        export type info = string;
    }

    export namespace Helper {
        export function getLicence () {
            return licence;
        }   
    }
}
