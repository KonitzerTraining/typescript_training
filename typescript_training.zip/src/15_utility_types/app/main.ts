// Partial<Type>
interface Todo {
    title: string;
    description: string;
}

type props = {
    date?: Date
}

// Partial<Type> and
// Intersection with &
function updateTodo(todo: Todo, fields:Partial<Todo & props>): Todo & props {
    return {
        ...todo,
        ...fields,
        date: new Date()
    };
} 

let todo: Todo = {
    title: "Organize",
    description: "Clear"
};

todo = updateTodo(todo, {description: "Clear Clutter"});
console.log(todo);

// Requires<Type>
interface Address {
    zip: string;
    city: string;
    phone?:string;
}

const myAddress1: Address = {
    zip: "l93849",
    city: "Hamburg"
};

function checkZip({zip}: Required<{zip: string}>) {
    return (typeof zip === "string")? zip: null;
}


const result1 = checkZip(myAddress1);
console.log(result1);

// Readonly<Car>
class Car {
    model = "Subaru";
    constructor() {
        Object.freeze(this);
    }
}

const myCar:Readonly<Car> = new Car();
console.log(myCar);

// myCar.model = 'Audi';
// myCar.color = "blue";
console.log(myCar);
