"use strict";
// Partial<Type> and
// Intersection with &
function updateTodo(todo, fields) {
    return {
        ...todo,
        ...fields,
        date: new Date()
    };
}
let todo = {
    title: "Organize",
    description: "Clear"
};
todo = updateTodo(todo, { description: "Clear Clutter" });
console.log(todo);
const myAddress1 = {
    zip: "l93849",
    city: "Hamburg"
};
function checkZip({ zip }) {
    return (typeof zip === "string") ? zip : null;
}
const result1 = checkZip(myAddress1);
console.log(result1);
// Readonly<Car>
class Car {
    constructor() {
        this.model = "Subaru";
        Object.freeze(this);
    }
}
const myCar = new Car();
console.log(myCar);
// myCar.model = 'Audi';
// myCar.color = "blue";
console.log(myCar);
//# sourceMappingURL=main.js.map