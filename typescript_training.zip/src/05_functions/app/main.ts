// ES3
var result = sum1(2,3);
console.log(result);
// Funktionsdefinition (erfährt Hoisting)
function sum1(a, b) { // TS will einen Datentyp sehen
    return a + b;
} 

// ES6 = ES2015
let result2 = sum2(2,3);
console.log(result2);

// Funktionsdefinition (erfährt Hoisting)
function sum2(a = 1, b = 2) { // Default-Wert
    return a + b;
} 
const sum3 = function sum3(a = 1, b = 3) {
    return a + b
}

result2 = sum3(8);
console.log(result2);

// Arrow
const sum4 = (a = 2, b = 5) => {
    return a * b;
}
result2 = sum4();
console.log(result2);

// Kurzschreibweise
const sum5 = x =>  x * x;
result2 = sum5(5);
console.log(result2);

let list2 = [4,5,6,6];
list2 = list2.map(item => item * 2);
console.log(list2);

//  TS
function ts1(): void {
    console.log('Kein Rückgabewert')
}
ts1();

function ts2(x: number, y = 1): number {
    return x + y
}
result2 = ts2(5);
console.log(result2);

const ts3 = (a: number, b = 1): number => {
    return a + b;
}
result2 = ts3(54,5);
console.log(result2);

const ts4 = (a: number, b: number = 1): number =>  a + b;
result2 = ts3(54,5);
console.log(result2);

const ts5: (x: number, y?: number) => number = (x: number, y: number = 1): number =>  x + y;
result2 = ts5(7);
console.log(result2);

type callback = (x: number, y?: number) => number;
const ts6:callback  = (a: number, b = 1): number =>  a + b;
result2 = ts6(9);
console.log(result2);


// overload signatures
function hire(person: string): string;
function hire(person: string[]):string[];
function hire(person: unknown): unknown {
    const textPart = 'is now part of our company.';

    let returnValue!: string | string[];
    if(typeof person === 'string') {
        returnValue = `${person} ${textPart}`; // ES6 template literal
    } else if(Array.isArray(person)) {
        return person.map(singlePerson => `${singlePerson} ${textPart}`);
    }
    return returnValue;
}

let result3: any; // Nur aus didaktischen Zwe
result3 = hire('Hans');
console.log(result3);
result3 = hire(['Hans', 'Peter']);
console.log(result3);

// never - Funktion erreicht eventuell nie den return-Ausdruck.
getValue('');

function getValue(url: string): string | never {
    if(typeof url !== 'string' || url?.length === 0) {
        throw new Error("no url specified");
    }

    return 'promise object';
}

// Interface mit Funktionsdefinition
interface lib {
    version: string;
    sum?(x : number): number; // hier als optional gekennzeichnet
}

const lib: lib = {
    version: "",
    sum(x: number): number {
        return x + x;
    }
/*     sum: function (x: number): number {
        throw new Error("Function not implemented.");
    } */
}
