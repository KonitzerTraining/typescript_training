// https://definitelytyped.org/
// https://www.typescriptlang.org/dt/search?search=underscor

/*
Beispiel unter node ausführen

package.json
      "type": "module",

tsconfig.json
    "moduleResolution": "node",
*/


import _ from "underscore";

_.each([4,5,6], (item) => console.log(item) );